Author: Abu Awal Md Shoeb
Rutgers University, New Brunswick, NJ, USA
Contact: abu.shoeb@rutgers.edu

Please cite our papers if you use any of the resources, thank you!

Paper 1
-------
EmoTag1200 👍 : Understanding the Association between Emojis 😄 and Emotions 😻. 
Abu Awal Md Shoeb, and Gerard de Melo
EMNLP 2020, November 2020. 

@InProceedings{ShoebDeMelo2020EmoTag1200,
  author = {Abu Awal Md Shoeb and de Melo, Gerard},
  title = {EmoTag1200: Understanding the Association between Emojis and Emotions},
  booktitle = {Proceedings of EMNLP 2020},
  year = {2020},
}


Paper 2
-------
EmoTag – Towards an Emotion-Based Analysis of Emojis.
Abu Awal Md Shoeb, Shahab Raji, Gerard de Melo.
RANLP 2019, September 2019.

@inproceedings{ShoebRajiDeMelo2019EmoTag,
  author    = {Abu Awal Md Shoeb and Shahab Raji and Gerard de Melo},
  title     = {{EmoTag} -- {T}owards an Emotion-Based Analysis of Emojis},
  booktitle = {Proceedings of RANLP 2019},
  location  = {Varna, Bulgaria},
  month     = {sep},
  year      = {2019},
  pages     = {1094-1103},
  url       = {https://www.aclweb.org/anthology/R19-1126},
  doi       = {10.26615/978-954-452-056-4_126},
  abstract  = {Despite being a fairly recent phenomenon, emojis have quickly become ubiquitous. Besides their extensive use in social media, they are now also invoked in customer surveys and feedback forms. Hence, there is a need for techniques to understand their sentiment and emotion. In this work, we provide a method to quantify the emotional association of basic emotions such as anger, fear, joy, and sadness for a set of emojis. We collect and process a unique corpus of 20 million emoji-centric tweets, such that we can capture rich emoji semantics using a comparably small dataset. We evaluate the induced emotion profiles of emojis with regard to their ability to predict word affect intensities as well as sentiment scores."},
}
